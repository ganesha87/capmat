<?php
	if(@$_REQUEST['id']!=""){
		$id = @$_REQUEST['id'];
		
		include '../api/lib/config/database.php';
		$mySqlObj = new MysqlDBConfig();
		$mySqlConn = $mySqlObj->getConnection();
		echo "Selected Capability Hierarchy (bottom-up):<br />";
		ShowParent($id, $mySqlConn,0);
		mysqli_close($mySqlConn);
	}
	
	function ShowParent($id, $conn,$indent){
		$query = 'SELECT TopLevel, Capability FROM `capabilities` WHERE CNo = '.$id.';';
		$results = $conn->query($query);
		
		while($result = mysqli_fetch_array($results)){
			$parent = $result['TopLevel'];
			for($i=0;$i<$indent;$i++){
				echo '&nbsp;&nbsp;';
			}
			echo '<b>'.$result['Capability'].'</b><br />';
		
			if($parent!=0){
				ShowParent($parent, $conn,$indent+1);
			}
		}
	}
?>