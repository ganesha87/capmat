<?php
	//include 'lib/config/database.php';
	$mySqlObj = new MysqlDBConfig();
	$mySqlConn = $mySqlObj->getConnection();
	
	$capabilities = $mySqlConn->query("SELECT CNo, Capability,Level FROM capabilities WHERE TopLevel = 0;");
	
	while ($capbility = mysqli_fetch_array($capabilities)) {
		
	?>
		<div class="col-sm-6 ">
		<table id="capabilitiesTable" class="table bootstrap-datatable">
			<tbody>
		<?php 					
		echo '<tr>';
		echo '<td><b>Category : <a class="btn btn-app" href="EditCapability.php?id='.$capbility['CNo'].'">'.$capbility['Capability'].'</a></b></td>';
		echo '</tr>';
		ListChildren($capbility['CNo'],1);		
		?>
						</tbody>
						</table>
						</div>
	<?php 
	}
	
	mysqli_close($mySqlConn);
	
	function ListChildren($CNo, $indent){
		$sqlObj = new MysqlDBConfig();
		$sqlConn = $sqlObj->getConnection();
		$children = $sqlConn->query("SELECT CNo, Capability,Level FROM capabilities WHERE TopLevel = ".$CNo.";");
		
		while ($child = mysqli_fetch_array($children)) {
			
			echo '<tr>';
			echo '<td>';
			for($i=0;$i<$indent;$i++){
				echo '&nbsp;&nbsp;';
			}
			echo '<a class="btn btn-app" href="EditCapability.php?id='.$child['CNo'].'">'.$child['Capability'].'</a></td>';
			echo '</tr>';
			ListChildren($child['CNo'],$indent+1);
		}
		
		mysqli_close($sqlConn);
	}
?>