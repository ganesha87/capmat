<?php
	include 'lib/config/database.php';
	include 'lib/data/capabilities.php';

	if(@$_REQUEST['capability']!="")
	{		
		CapabilityDBInterface::AddCapability($_REQUEST("capability"),"", $_REQUEST("parentcapability"));
	}
?>