<?php
	class CapabilityData {
		public $cNo = null;
		public $capability = null;
		public $notes = null;
		public $topLevel = null;
		public $level = null;
		public $lastAction = null;
		public $active = null;		
	}
?>