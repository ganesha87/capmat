<?php
	class VendorData{
		public $vNo = null;
		public $vendor = null;
		public $notes = null;
		public $url = null;
		public $lastAction = null;
		public $active = null;
	}
?>