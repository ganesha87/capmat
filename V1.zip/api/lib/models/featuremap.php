<?php
	class FeatureMapData{
		public $fNo = null;
		public $feature = null;
		public $cNo = null;
		public $capability = null;
		public $vNo = null;
		public $vendor = null;
	}
?>