<?php
	class CapMatrixData{
		public $mNo = null;
		public $cNo = null;
		public $capability = null;
		public $vNo = null;
		public $vendor = null;
	}
?>