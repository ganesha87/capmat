<?php
	class FeatureData{
		public $fNo = null;
		public $feature = null;
		public $description = null;
		public $weight = null;
		public $cNo = null;
		public $capability = null;
	}
?>